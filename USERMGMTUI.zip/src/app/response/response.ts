export interface BranchDto {

    branchName: String;
    branchCode: String;
    status: String;

}
