export class BranchDto {
    branchCode: string;
    branchName: string;
    action: string;
    status: string;
}