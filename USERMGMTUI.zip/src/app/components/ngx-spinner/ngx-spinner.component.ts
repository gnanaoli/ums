import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ngx-spinner',
  templateUrl: './ngx-spinner.component.html',
  styleUrls: ['./ngx-spinner.component.scss']
})
export class NgxSpinnerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
