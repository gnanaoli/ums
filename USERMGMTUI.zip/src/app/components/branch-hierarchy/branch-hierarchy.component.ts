import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-branch-hierarchy',
  templateUrl: './branch-hierarchy.component.html',
  styleUrls: ['./branch-hierarchy.component.scss']
})
export class BranchHierarchyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
