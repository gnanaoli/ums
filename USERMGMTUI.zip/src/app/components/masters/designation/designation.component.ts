import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from "@angular/forms";
import { HttpClient } from '@angular/common/http';
import Swal from 'sweetalert2'
import { AppConstants } from 'src/app/constants/AppConstants';

import { DesignationService } from "../../../services/designationService";
import { DataTableService } from '../../../services/dataTableService';

@Component({
  selector: 'app-designation',
  templateUrl: './designation.component.html',
  styleUrls: ['./designation.component.scss']
})
export class DesignationComponent implements OnInit {


  tableGrid: Boolean = true;

  tableGridData: any[] = [];

  designationList: any[] = [];

  title: String = "Designation Master";

  form: Boolean = false;

  formDetails: FormGroup;

  designationSearchForm: FormGroup;

  constructor(private dataTableService: DataTableService, private http: HttpClient, private fb: FormBuilder, private designationService: DesignationService) {

    this.getAllDesignation();

  }

  ngOnInit(): void {

    this.designationSearchForm = this.fb.group({

      designationCode: [null],
      designation: [null],
      status: [null],

    });

    this.formDetails = this.fb.group({

      designationCode: ['', [Validators.required]],
      designation: ['', [Validators.required]],
      status: [''],
      action: [AppConstants.NEW, [Validators.required]],

    })

  }

  showForm() {

    this.formDetails.reset();

    this.formDetails.patchValue({ action: AppConstants.NEW });

    this.title = "Add / Edit Designation";

    this.form = true;
    this.tableGrid = false;

  }

  get validate_form() {
    return this.formDetails.controls;
  }

  showGrid() {

    this.title = "Designation Master";

    this.form = false;
    this.tableGrid = true;

    this.getAllDesignation();

  }

  getAllDesignation() {

    this.dataTableService.dataTableDestory();

    this.designationService.getAllDesignation().subscribe(data => {

      this.tableGridData = data['responseDto'];
      this.designationList = data['responseDto'];

      this.dataTableService.dataTableReinitalize();

    })

  }

  save() {

    console.log(this.formDetails.value);

    if (this.formDetails.valid) {


      this.designationService.saveDesignation(this.formDetails.value).subscribe((data) => {

        if (data['status'] == AppConstants.SUCCESS) {

          Swal.fire({
            icon: 'success',
            title: '',
            text: data['msg'],
          }).then((result) => {
            if (result.isConfirmed) {

              this.getAllDesignation();
              this.showGrid();

            } else if (result.isDenied) {

            }
          })

        } else {

          Swal.fire({
            icon: 'error',
            title: '',
            text: data['exceptionMsg'],
          })

        }

      });

    }

  }


  editDesignation(input) {

    this.showForm();

    this.formDetails.patchValue(
      {
        designationCode: input.designationCode,
        designation: input.designation,

        action: AppConstants.EDIT,
        status: input.status,
      }
    );

  }
  searchDesignation() {

    this.dataTableService.dataTableDestory();

    this.designationService.searchDesignation(this.designationSearchForm.value).subscribe((data: any) => {

      this.tableGridData = data.responseDto;

      this.dataTableService.dataTableReinitalize();

    })

  }

  searchDesignationReset() {

    this.designationSearchForm.reset();

    this.getAllDesignation();

  }

}
