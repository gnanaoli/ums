import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, FormArray, Validators } from "@angular/forms";
import { HttpClient } from '@angular/common/http';
import Swal from 'sweetalert2';
import { AppConstants } from "../../../constants/AppConstants";

import { AppMasterService } from '../../../services/appmasterService';
import { AppRoleMappingService } from "../../../services/app_role_mapping_service";
import { DataTableService } from '../../../services/dataTableService';

@Component({
  selector: 'app-app-role-mapping',
  templateUrl: './app-role-mapping.component.html',
  styleUrls: ['./app-role-mapping.component.scss']
})
export class AppRoleMappingComponent implements OnInit {

  tableGrid: Boolean = true;

  tableGridData: any[] = [];

  appList: any[] = [];

  appRoleList: any[] = [];

  applicationRoleMappingDtoList: any[] = [];

  title: String = "Application Role Mapping";

  form: Boolean = false;

  formDetails: FormGroup;

  appRoleSearchForm: FormGroup;


  constructor(private dataTableService: DataTableService, private fb: FormBuilder, private appRoleMappingService: AppRoleMappingService, private appmasterService: AppMasterService) {

  }

  ngOnInit(): void {

    this.appRoleSearchForm = this.fb.group({

      applicationCode: [null],
      applicationName: [null],
      roleCode: [null],
      roleName: [null],
      status: [null],

    });

    this.formDetails = this.fb.group({
      id: [''],
      applicationCode: ['', [Validators.required]],
      applicationName: ['', [Validators.required]],
      roleCode: ['', [Validators.required]],
      roleName: ['', [Validators.required]],
      status: [''],
      action: AppConstants.NEW
    })

    this.getAllAppMappedRoleList();
    this.getallApplication();

  }

  get validate_form() {
    return this.formDetails.controls;
  }


  getallApplication() {

    this.appmasterService.getallApplication().subscribe(data => {
      this.appList = data['responseDto'];
    })


  }

  addApp() {

    if (this.formDetails.valid) {

      this.applicationRoleMappingDtoList.push(this.formDetails.value);

    }

  }

  remove(index) {

    // this.app.removeAt(index);

    this.applicationRoleMappingDtoList.splice(index, 1);

  }

  showForm() {

    this.applicationRoleMappingDtoList = [];

    this.formDetails.reset();

    this.formDetails.patchValue({ action: AppConstants.NEW });

    this.title = "Add / Edit Employee";

    this.form = true;
    this.tableGrid = false;

  }

  showGrid() {

    this.form = false;
    this.tableGrid = true;

    this.getAllAppMappedRoleList();

  }


  save() {

    if (this.formDetails.get('action').value == AppConstants.EDIT) {

      this.applicationRoleMappingDtoList = [];

      this.applicationRoleMappingDtoList.push(this.formDetails.value);

    }

    if (this.applicationRoleMappingDtoList.length > 0) {


      this.appRoleMappingService.saveAppRoleMapping(this.applicationRoleMappingDtoList).subscribe((data) => {

        if (data['status'] == AppConstants.SUCCESS) {

          Swal.fire({
            icon: 'success',
            title: '',
            text: data['msg'],
          }).then((result) => {
            if (result.isConfirmed) {

              this.showGrid();

            } else if (result.isDenied) {

            }
          })

        } else {

          Swal.fire({
            icon: 'error',
            title: '',
            text: data['exceptionMsg'],
          })

        }

        console.log("res" + JSON.stringify(data))
      });

    }

  }

  getAllAppMappedRoleList() {

    this.dataTableService.dataTableDestory();

    this.appRoleMappingService.getApplicationGroupBy().subscribe((data: any) => {

      this.tableGridData = data.responseDto;
      this.appRoleList = data.responseDto;

      this.dataTableService.dataTableReinitalize();

    })

  }

  edit(item) {

    console.log(item);

    this.showForm();

    item.action = AppConstants.EDIT;

    this.formDetails.patchValue(item);

    this.formDetails.patchValue({ action: AppConstants.EDIT });


  }


  searchAppRole() {

    this.appRoleMappingService.searchAppRole(this.appRoleSearchForm.value).subscribe((data: any) => {

      this.tableGridData = data.responseDto;

    })

  }

  searchAppRoleReset() {

    this.appRoleSearchForm.reset();

    this.getAllAppMappedRoleList();

  }

}
