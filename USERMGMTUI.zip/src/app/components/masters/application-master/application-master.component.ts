import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AppMasterService } from '../../../services/appmasterService';
import { DataTableService } from '../../../services/dataTableService';
import Swal from 'sweetalert2';

import { AppConstants } from "../../../constants/AppConstants";


@Component({
  selector: 'app-application-master',
  templateUrl: './application-master.component.html',
  styleUrls: ['./application-master.component.scss']
})

export class ApplicationMasterComponent implements OnInit {

  tableGrid: Boolean = true;

  tableGridData: any[] = [];

  appList: any[] = [];

  title: String = "Application Master";

  form: Boolean = false;

  readOnly: Boolean = false;

  formDetails: FormGroup;

  applicationSearchForm: FormGroup;

  constructor(private dataTableService: DataTableService, private http: HttpClient, private fb: FormBuilder, private appmasterService: AppMasterService) {

    this.getallApplication();
  }

  ngOnInit(): void {

    this.applicationSearchForm = this.fb.group({

      applicationCode: [null],
      applicationName: [null],
      status: [null],

    });

    this.formDetails = this.fb.group({

      id: [''],
      applicationCode: ['', [Validators.required]],
      applicationName: ['', [Validators.required]],
      status: [''],
      action: [AppConstants.NEW, [Validators.required]],

    })



  }

  showForm() {

    this.title = "Add/ Edit Application";

    this.formDetails.reset();

    this.formDetails.patchValue({ action: AppConstants.NEW });

    this.form = true;

    this.tableGrid = false;

    this.readOnly = false;

  }

  get validate_form() {
    return this.formDetails.controls;
  }

  showGrid() {

    this.title = "Application Master";

    this.form = false;

    this.tableGrid = true;

    this.getallApplication();

  }

  getallApplication() {

    this.dataTableService.dataTableDestory();

    this.appmasterService.getallApplication().subscribe(data => {

      this.tableGridData = data['responseDto'];
      this.appList = data['responseDto'];

      this.dataTableService.dataTableReinitalize();

    })


  }

  save() {


    console.log(this.formDetails.value);

    if (this.formDetails.valid) {

      // this.http.post(AppConstants.SAVE_APPLICATION_DETAILS, this.formDetails.value).subscribe((data) => {
      this.appmasterService.saveAppMaster(this.formDetails.value).subscribe((data) => {

        if (data['status'] == AppConstants.SUCCESS) {


          Swal.fire({
            icon: 'success',
            title: '',
            text: data['msg'],
          }).then((result) => {
            if (result.isConfirmed) {

              this.getallApplication();
              this.showGrid();

            } else if (result.isDenied) {

            }
          })



        } else {

          Swal.fire({
            icon: 'error',
            title: '',
            text: data['exceptionMsg'],
          })

        }

        console.log("res" + JSON.stringify(data))


      })

    }
  }


  editApplication(input) {

    this.showForm();

    this.readOnly = true;

    this.formDetails.patchValue(
      input
    );

    this.formDetails.patchValue(
      { action: AppConstants.EDIT }
    );

  }


  searchAppMaster() {

    this.dataTableService.dataTableDestory();

    this.appmasterService.searchAppMaster(this.applicationSearchForm.value).subscribe((data: any) => {

      this.tableGridData = data.responseDto;

      this.dataTableService.dataTableReinitalize();

    })

  }

  searchAppMasterReset() {

    this.applicationSearchForm.reset();

    this.getallApplication();

  }



}
