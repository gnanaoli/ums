import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from "@angular/forms";
import { HttpClient } from '@angular/common/http';
import Swal from 'sweetalert2';
import { AppConstants } from "../../../constants/AppConstants";

import { ITSupportService } from './../../../services/itsupportService';
import { EmployeeService } from '../../../services/employeeService';
import { AppMasterService } from '../../../services/appmasterService';
import { DataTableService } from '../../../services/dataTableService';


@Component({
  selector: 'app-it-support-mapping',
  templateUrl: './it-support-mapping.component.html',
  styleUrls: ['./it-support-mapping.component.scss']
})
export class ItSupportMappingComponent implements OnInit {

  tableGrid: Boolean = true;

  tableGridData: any[] = [];

  employeeList: any[] = [];

  appList: any[] = [];

  title: String = "ITSupportMapping";

  form: Boolean = false;

  formDetails: FormGroup;

  itSearchForm: FormGroup;

  constructor(private dataTableService: DataTableService, private http: HttpClient, private fb: FormBuilder, private itSupportService: ITSupportService, private employeeService: EmployeeService, private appmasterService: AppMasterService) {

    this.getAllITSupport();

  }

  ngOnInit(): void {

    this.itSearchForm = this.fb.group({

      applicationName: [null],
      empId: [null],
      status: [null],

    });

    this.formDetails = this.fb.group({

      id: [''],
      applicationName: ['', [Validators.required]],
      empId: ['', [Validators.required]],
      status: [''],
      action: [AppConstants.NEW, [Validators.required]],

    })

    this.getAllEmployee();

    this.getallApplication();

  }

  get validate_form() {
    return this.formDetails.controls;
  }

  getAllITSupport() {

    this.dataTableService.dataTableDestory();

    this.itSupportService.getAllItsupport().subscribe(data => {

      this.tableGridData = data['responseDto'];

      this.dataTableService.dataTableReinitalize();

    })

  }


  getallApplication() {

    this.appmasterService.getallApplication().subscribe(data => {
      console.log("---" + JSON.stringify(data))
      this.appList = data['responseDto'];
    })


  }

  getAllEmployee() {

    this.employeeService.getAllEmployee().subscribe((data: any) => {

      this.employeeList = data.responseDto;

    })

  }

  showGrid() {

    this.formDetails.reset();

    this.formDetails.patchValue({ action: AppConstants.NEW });

    this.title = "ITSupportMapping";

    this.form = false;
    this.tableGrid = true;

    this.getAllITSupport();

  }

  showForm() {

    this.formDetails.reset();

    this.formDetails.patchValue({ action: AppConstants.NEW });

    this.title = "Add / Edit ITSupportMapping";

    this.form = true;
    this.tableGrid = false;

  }

  save() {

    console.log(this.formDetails.value);

    if (this.formDetails.valid) {

      this.itSupportService.saveItsupport(this.formDetails.value).subscribe((data) => {

        if (data['status'] == AppConstants.SUCCESS) {

          Swal.fire({
            icon: 'success',
            title: '',
            text: data['msg'],
          }).then((result) => {
            if (result.isConfirmed) {

              this.showGrid();

            } else if (result.isDenied) {

            }
          })

        } else {

          Swal.fire({
            icon: 'error',
            title: '',
            text: data['exceptionMsg'],
          })

        }

        console.log("res" + JSON.stringify(data))
      });

    }

  }


  editItSupport(input) {

    this.showForm();

    this.formDetails.patchValue(
      input
    );

    this.formDetails.patchValue({ action: AppConstants.EDIT });

  }


  searchITSupport() {

    this.itSupportService.searchITSupport(this.itSearchForm.value).subscribe((data: any) => {

      this.tableGridData = data.responseDto;

    })

  }

  searchITSupportReset() {

    this.itSearchForm.reset();

    this.getAllITSupport();

  }

}
