import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from "@angular/forms";
import { HttpClient } from '@angular/common/http';
import Swal from 'sweetalert2'
import { AppConstants } from 'src/app/constants/AppConstants';

import { assetMaster } from "../../../services/assetMaster";
import { DataTableService } from '../../../services/dataTableService';

@Component({
  selector: 'app-asset',
  templateUrl: './asset.component.html',
  styleUrls: ['./asset.component.scss']
})
export class AssetComponent implements OnInit {

  tableGrid: Boolean = true;

  tableGridData: any[] = [];

  title: String = "Asset Master";

  form: Boolean = false;

  formDeatils: FormGroup;

  constructor(private dataTableService: DataTableService, private http: HttpClient, private fb: FormBuilder, private assetMaster: assetMaster) {



  }

  ngOnInit(): void {

    this.formDeatils = this.fb.group({

      assetType: ['', [Validators.required]],
      status: [''],
      action: [AppConstants.NEW, [Validators.required]],

    })

    this.getAllAsset();

  }

  get validate_form() { return this.formDeatils.controls; }

  showForm() {

    this.formDeatils.reset();

    this.formDeatils.patchValue({ action: AppConstants.NEW });

    this.title = "Add / Edit Asset";

    this.form = true;
    this.tableGrid = false;

  }

  showGrid() {

    this.title = "Asset Master";

    this.form = false;
    this.tableGrid = true;

    this.getAllAsset();

  }

  getAllAsset() {

    this.dataTableService.dataTableDestory();

    this.assetMaster.getAllAsset().subscribe(data => {

      this.tableGridData = data['responseDto'];

      this.dataTableService.dataTableReinitalize();

    })

  }

  save() {

    console.log(this.formDeatils.value);

    if (this.formDeatils.valid) {


      this.assetMaster.saveAsset(this.formDeatils.value).subscribe((data) => {

        if (data['status'] == AppConstants.SUCCESS) {

          Swal.fire({
            icon: 'success',
            title: '',
            text: data['msg'],
          }).then((result) => {
            if (result.isConfirmed) {

              this.showGrid();

            } else if (result.isDenied) {

            }
          })

        } else {

          Swal.fire({
            icon: 'error',
            title: '',
            text: data['exceptionMsg'],
          })

        }

        console.log("res" + JSON.stringify(data))
      });

    }

  }


  editAsset(input) {

    this.showForm();

    this.formDeatils.patchValue(
      {
        assetType: input.assetType,

        action: AppConstants.EDIT,
        status: input.status,
      }
    );

  }

}
