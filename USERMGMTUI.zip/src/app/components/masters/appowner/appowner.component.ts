import { EmployeeService } from './../../../services/employeeService';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from "@angular/forms";
import { HttpClient } from '@angular/common/http';
import Swal from 'sweetalert2'
import { AppConstants } from '../../../constants/AppConstants';


import { AppOwnerService } from "../../../services/appownerService";
import { AppMasterService } from '../../../services/appmasterService';
import { DataTableService } from '../../../services/dataTableService';


@Component({
  selector: 'app-appowner',
  templateUrl: './appowner.component.html',
  styleUrls: ['./appowner.component.scss']
})
export class AppownerComponent implements OnInit {

  tableGrid: Boolean = true;

  tableGridData: any[] = [];

  appOwnerList: any[] = [];

  appList: any[] = [];

  empList: any[] = [];

  title: String = "App Owner Master";

  form: Boolean = false;

  formDeatils: FormGroup;

  appOwnerSearchForm: FormGroup;

  constructor(private dataTableService: DataTableService, private http: HttpClient, private employeeService: EmployeeService, private appOwnerService: AppOwnerService, private fb: FormBuilder, private appmasterService: AppMasterService) {


  }

  ngOnInit(): void {

    this.getAllAppOwner();

    this.getAllEmp();

    this.appOwnerSearchForm = this.fb.group({

      applicationCode: [null],
      empId: [null],
      applicationOwner: [null],
      status: [null],

    });


    this.formDeatils = this.fb.group({

      id: [''],
      applicationCode: ['', [Validators.required]],
      empId: ['', [Validators.required]],
      applicationOwner: ['', [Validators.required]],
      status: [''],
      action: [AppConstants.NEW, [Validators.required]],


    })

    this.getallApplication();

  }

  get validate_form() {

    return this.formDeatils.controls;

  }

  showForm() {

    this.formDeatils.reset();

    this.formDeatils.patchValue({ action: AppConstants.NEW });

    this.title = "Add / Edit App Owner";

    this.form = true;
    this.tableGrid = false;

  }

  showGrid() {

    this.title = "App Owner Master";

    this.form = false;
    this.tableGrid = true;

    this.getAllAppOwner();

  }

  getAllAppOwner() {

    this.dataTableService.dataTableDestory();

    this.appOwnerService.getAllAppOwner().subscribe(data => {

      this.tableGridData = data['responseDto'];
      this.appOwnerList = data['responseDto'];

      this.dataTableService.dataTableReinitalize();

    })

  }

  getallApplication() {


    this.appmasterService.getallApplication().subscribe(data => {
      this.appList = data['responseDto'];

    })


  }

  save() {

    console.log(this.formDeatils.value);

    if (this.formDeatils.valid) {

      this.appOwnerService.saveAppOwner(this.formDeatils.value).subscribe((data) => {

        if (data['status'] == AppConstants.SUCCESS) {

          Swal.fire({
            icon: 'success',
            title: '',
            text: data['msg'],
          }).then((result) => {
            if (result.isConfirmed) {

              this.getAllAppOwner();
              this.showGrid();

            } else if (result.isDenied) {

            }
          })

        } else {

          Swal.fire({
            icon: 'error',
            title: '',
            text: data['exceptionMsg'],
          })

        }

      });

    }

  }


  editDesignation(input) {


    this.showForm();

    this.formDeatils.patchValue(
      input
    );

    this.formDeatils.patchValue({ action: AppConstants.EDIT });

  }
  searchAppOwner() {

    this.appOwnerService.searchAppOwner(this.appOwnerSearchForm.value).subscribe((data: any) => {

      this.tableGridData = data.responseDto;

    })

  }

  searchAppOwnerReset() {

    this.appOwnerSearchForm.reset();

    this.getAllAppOwner();

  }

  getAllEmp() {

    this.employeeService.getAllEmployee().subscribe((data: any) => {

      this.empList = data.responseDto;

    })

  }


}
