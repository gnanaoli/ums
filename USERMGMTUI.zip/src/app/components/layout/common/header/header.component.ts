import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/services/loginService';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {


  loginDetails: any = {};


  constructor(private router: Router, private loginService: LoginService) { }

  ngOnInit(): void {

    this.loginDetails['userName'] = localStorage.getItem('userName');

    this.loginDetails['userId'] = localStorage.getItem('userId');

    this.loginDetails['roleName'] = localStorage.getItem('roleName');

  }

  logout() {

    // this.loginService.logout().subscribe();

    localStorage.clear();
    this.router.navigateByUrl('/login');

  }

}
